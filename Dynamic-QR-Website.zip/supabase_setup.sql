-- Dynamic QR: قاعدة بيانات العروض وصلاحياتها
-- يعتمد هذا الملف على وجود public.site_admins(user_id uuid) ودالة public.is_site_admin()
-- التي أنشأتهما سابقاً. نفّذ من Supabase > SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.offers (
  id uuid primary key default gen_random_uuid(),
  title_ar text not null,
  title_en text,
  description_ar text,
  description_en text,
  target_url text,
  image_path text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.offers enable row level security;

drop policy if exists "Public can read active offers" on public.offers;
create policy "Public can read active offers"
on public.offers for select to anon, authenticated
using (is_active = true);

drop policy if exists "Admins can read all offers" on public.offers;
create policy "Admins can read all offers"
on public.offers for select to authenticated
using (public.is_site_admin());

drop policy if exists "Admins can insert offers" on public.offers;
create policy "Admins can insert offers"
on public.offers for insert to authenticated
with check (public.is_site_admin());

drop policy if exists "Admins can update offers" on public.offers;
create policy "Admins can update offers"
on public.offers for update to authenticated
using (public.is_site_admin())
with check (public.is_site_admin());

drop policy if exists "Admins can delete offers" on public.offers;
create policy "Admins can delete offers"
on public.offers for delete to authenticated
using (public.is_site_admin());

-- إنشاء bucket إن لم يكن موجوداً. عام لعرض صور العروض.
insert into storage.buckets (id, name, public)
values ('offers', 'offers', true)
on conflict (id) do update set public = true;

drop policy if exists "Public can view offer images" on storage.objects;
create policy "Public can view offer images"
on storage.objects for select to anon, authenticated
using (bucket_id = 'offers');

drop policy if exists "Admins can upload offer images" on storage.objects;
create policy "Admins can upload offer images"
on storage.objects for insert to authenticated
with check (bucket_id = 'offers' and public.is_site_admin());

drop policy if exists "Admins can update offer images" on storage.objects;
create policy "Admins can update offer images"
on storage.objects for update to authenticated
using (bucket_id = 'offers' and public.is_site_admin())
with check (bucket_id = 'offers' and public.is_site_admin());

drop policy if exists "Admins can delete offer images" on storage.objects;
create policy "Admins can delete offer images"
on storage.objects for delete to authenticated
using (bucket_id = 'offers' and public.is_site_admin());

grant select on public.offers to anon, authenticated;
grant insert, update, delete on public.offers to authenticated;
